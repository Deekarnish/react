import React from "react";
import ReactDOM from "react-dom/client";
import { StyledEngineProvider } from "@mui/styled-engine";
import { ThemeProvider } from "@emotion/react";
import { theme } from "./theme";
import "./assets/fonts/Mulish/Mulish-Regular.ttf";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import { ApiProvider } from "./context/ApiContext";
import { ProgressProvider } from "./context/ProgressContext";
import { BrowserRouter } from "react-router-dom";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  <React.StrictMode>
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <ApiProvider>
          <ProgressProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </ProgressProvider>
        </ApiProvider>
      </ThemeProvider>
    </StyledEngineProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
