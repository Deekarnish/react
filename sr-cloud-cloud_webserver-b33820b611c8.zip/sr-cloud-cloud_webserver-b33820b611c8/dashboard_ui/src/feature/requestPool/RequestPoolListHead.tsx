import {
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
  Box
} from "@mui/material";
import { RequestPool, Order } from "../../types";
import { visuallyHidden } from "@mui/utils";

interface HeadCell {
  disablePadding: boolean;
  id: keyof RequestPool;
  label: string;
  numeric: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "trackingId",
    numeric: false,
    disablePadding: true,
    label: "Ticket ID",
  },
  {
    id: "hapi",
    numeric: false,
    disablePadding: false,
    label: "Payload Details",
  },
  {
    id: "node",
    numeric: false,
    disablePadding: false,
    label: "Node",
  },
  {
    id: "createdOn",
    numeric: false,
    disablePadding: false,
    label: "Created On",
  },
  {
    id: "lastUpdatedOn",
    numeric: false,
    disablePadding: false,
    label: "Last Updated On",
  },
  {
    id: "isCompleted",
    numeric: false,
    disablePadding: false,
    label: "Status",
  },
  {
    id: "messageDetail",
    numeric: false,
    disablePadding: false,
    label: "Details",
  },
];

interface RequestPoolListProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof RequestPool
  ) => void;
  order: Order;
  orderBy: string;
}

function RequestPoolListHead(props: RequestPoolListProps) {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof RequestPool) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        <TableCell></TableCell>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{color:"#000"}}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
        <TableCell></TableCell>
      </TableRow>
    </TableHead>
  );
}

export default RequestPoolListHead;
