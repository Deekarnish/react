import SvgIcon, { SvgIconProps } from "@mui/material/SvgIcon";
import React from "react";

function MoreVert(props: SvgIconProps) {
  return (
    <SvgIcon {...props}>
      <path
        d="M12 8C13.1 8 14 7.1 14 6C14 4.9 13.1 4 12 4C10.9 4 10 4.9 10 6C10 7.1 10.9 8 12 8ZM12 10C10.9 10 10 10.9 10 12C10 13.1 10.9 14 12 14C13.1 14 14 13.1 14 12C14 10.9 13.1 10 12 10ZM12 16C10.9 16 10 16.9 10 18C10 19.1 10.9 20 12 20C13.1 20 14 19.1 14 18C14 16.9 13.1 16 12 16Z"
        fill="#C5C7CD"
      />
    </SvgIcon>
  );
}

export default MoreVert;
