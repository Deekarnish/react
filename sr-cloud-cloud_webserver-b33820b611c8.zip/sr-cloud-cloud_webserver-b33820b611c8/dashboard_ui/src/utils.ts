import { Order } from "./types";

export function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

export function getComparator<Key extends keyof any>(
  order: Order,
  orderBy: Key
): (
  a: { [key in Key]: number | string | Date | Array<string> | undefined },
  b: { [key in Key]: number | string | Date | Array<string> | undefined }
) => number {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// Since 2020 all major browsers ensure sort stability with Array.prototype.sort().
// stableSort() brings sort stability to non-modern browsers (notably IE11).
export function stableSort<T>(
  array: readonly T[],
  comparator: (a: T, b: T) => number
) {
  const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

// export const handleQuery = (params: any) => {
//   let str = "";
//   Object.keys(params).map((key) => {
//     if (str != "") {
//       str += "&";
//     }
//     str += key + "=" + encodeURIComponent(params[key]);
//   });
//   return str;
// };

export const handleQuery = (params:any) => {
  const query = Object.keys(params)
      .map(key => {
          if (Array.isArray(params[key])) {
              return params[key].map((val:any) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`).join('&');
          }
          return `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`;
      })
      .join('&');
  return query;
};

export const getStatus = (statusId: number) => {
  let status: string = "";
  switch (statusId) {
    case 1:
      status = "Active";
      break;
    case 2:
      status = "In Active";
      break;
    case 3:
      status = "Running";
      break;
    case 4:
      status = "DUT Changing";
      break;
    case 5:
      status = "Engaged";
      break;
    case 6:
      status = "DUT Change Init";
      break;
    case 7:
      status = "Ver On Going";
      break;
    case 8:
      status = "Ver Complete";
      break;
    case 9:
      status = "Ver Failed";
      break;
    case 10:
      status = "Maintenance";
      break;
    case 12:
      status = "On Hold";
      break;
    case 11:
      status = "Error";
      break;
    case 13:
      status = "Not Verified";
      break;
  }
  return status;
};
