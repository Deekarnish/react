import {  Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import TrendsChart from "../components/graphs/TrendsChart";
import { createRequest } from "../services/ApiServices";
import Measurement from "../components/graphs/Measurement";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";
import { CSVLink, CSVDownload } from "react-csv";

function Home() {
  const [initData, setInitData] = useState({});
  const [graphData, setGraphData] = useState({});
  const [displayedText, setDisplayedText] = useState("Trends");
  const [startDate, setStartDate] = useState(
    new Date(new Date().setDate(new Date().getDate() - 10))
  );
  const [endDate, setEndDate] = useState(new Date());
  const [cardnumber, setCardNumber] = useState<any>();
  const [downloadData, setDownloadData] = useState([])
  const [downloadDataPerfor, setDownloadDataPerfor] = useState([])

  const colors = ["#2ACB27", "#3751FF", "#E31919", "#252733", "#FEC400"];
  const boxvalues = [
    {
      id: 1,
      status: "Active",
      number: 0,
    },
    {
      id: 2,
      status: "DUT Changing",
      number: 0,
    },
    {
      id: 3,
      status: "Error",
      number: 0,
    },
    {
      id: 4,
      status: "On Hold",
      number: 0,
    },
    {
      id: 5,
      status: "Maintenance",
      number: 0,
    },
  ];

  const getCardStatus = async () => {
    createRequest({
      api: "dashboardCard",
      method: "fetch_all",
    })?.then(async (res: any) => {
      const data = res.data;
      
      const statusMap: any = {
        1: "Active",
        11: "Error",
        12: "On Hold",
        10: "Maintenance",
        4: "DUT Changing",
      };

      for (let box of boxvalues) {
        box.number = 0;
      }

      for (let item of data) {
        for (let box of boxvalues) {
          if (box.status === statusMap[item.nodeStatusId]) {
            box.number = item.currentCount;

          }
        }
      }

      setCardNumber(boxvalues);
    });
  };

  const fetchGraphData = async () => {
    createRequest({
      api: "dashboardGraph",
      method: "fetch_all",
      params: {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      },
    })
      ?.then(async (res) => {
        setDownloadData(res?.data);
        const labels: string[] = [];
        const labels1: any = {
          date: [],
          activeCount: [],
          errorCount: [],
          inactiveCount: [],
          onHoldCount: [],
        };
        res.data.forEach((d: any) => {
          let sortDate = moment.utc(d.date).format('DD/MM/YYYY');
          labels.push(sortDate);
          labels1["activeCount"].push(d.activeCount);
          labels1["errorCount"].push(d.errorCount);
          labels1["inactiveCount"].push(d.inactiveCount);
          labels1["onHoldCount"].push(d.onHoldCount);
        });


        const data = {
          labels,
          datasets: [
            {
              label: "Active Count",
              data: labels1["activeCount"],
              borderColor: 'rgb(255, 99, 132)',
              backgroundColor: "rgb(255, 99, 132)",
              tension: 0.3,
              fill: true,
            },
            {
              label: "Error Count",
              data: labels1["errorCount"],
              borderColor: 'rgb(75, 192, 192)',
              backgroundColor: "rgb(75, 192, 192)",
              tension: 0.2,
              fill: true,
            },
            {
              label: "On Hold Count",
              data: labels1["onHoldCount"],
              borderColor: 'rgb(53, 162, 235)',
              backgroundColor: "rgb(53, 162, 235)",
              tension: 0.2,
              fill: true,
            },
            {
              label: "Inactive Count",
              data: labels1["inactiveCount"],
              borderColor: 'rgba(105, 83, 244, 0.8)',
              backgroundColor: "rgba(105, 83, 244, 0.8)",
              tension: 0.2,
              fill: true,
            },
          ],
        };

        setGraphData(data);
        setDisplayedText("Trends");
        setInitData(data);
      })
      ?.catch((err) => { });
  };

  const fetchrequestData = async () => {
    createRequest({
      api: "dashboardRequest",
      method: "fetch_all",
      params: {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      },
    })
      ?.then(async (res) => {
        setDownloadDataPerfor(res?.data)
        console.log(downloadDataPerfor, "perdnfbdhfbdhfbdfhb");

        const labels: string[] = [];
        const labels1: any = {
          date: [],
          averageResponseTime: [],
          requestSent: [],
          responseReceived: [],
        };
        res.data.forEach((d: any) => {
          let sortDate = moment.utc(d.date).format('DD/MM/YYYY');
          labels.push(sortDate);
          labels1["averageResponseTime"].push(d.averageResponseTime);
          labels1["requestSent"].push(d.requestSent);
          labels1["responseReceived"].push(d.responseReceived);
        });

        labels.sort((a: string, b: string) => {
          const [dayA, monthA, yearA] = a.split('/').map(Number);
          const [dayB, monthB, yearB] = b.split('/').map(Number);

          if (yearA !== yearB) {
            return yearA - yearB;
          }
          if (monthA !== monthB) {
            return monthA - monthB;
          }
          return dayA - dayB;
        });

        const data = {
          labels,
          datasets: [
            {
             label : "Average ResponseTime",
              data: labels1["averageResponseTime"],
              borderColor:"rgb(255, 99, 132)",
              backgroundColor: "rgb(255, 99, 132)",
              tension: 0.3,
              fill: true,
            },
            {
              label: "RequestSent",
              data: labels1["requestSent"],
              borderColor:"rgb(75, 192, 192)",
              backgroundColor: "rgb(75, 192, 192)",
              tension: 0.3,
              fill: true,
            },
            {
              label: "Response Received",
              data: labels1["responseReceived"],
              borderColor:"rgb(53, 162, 235)",
              backgroundColor: "rgb(53, 162, 235)",
              tension: 0.3,
              fill: true,
            },
          ],
        };
      

        setGraphData(data);
        setDisplayedText("Performance");
      })
      ?.catch((err: any) => {
        console.log(err, "Error Message");
      });
  };

  const handleMeasurement = () => {
    setDisplayedText("Measurement");
  };

  useEffect(() => {
    if (displayedText === "Trends") {
      fetchGraphData();
    } else {
      fetchrequestData();
    }
    getCardStatus();
  }, [startDate, endDate]);

  const roleId = localStorage.getItem("roleId");

  return (
    <>

      <div
        style={roleId === "2" ? { display: "none" } : {}}
      >
        <div className="box_container">
          {cardnumber?.map((item: any, index: any) => {
            return (
              <Box
                py={2}
                // width={220}
                display="flex"
                alignItems="center"
                flexDirection="column"
                component="div"
                borderRadius="10px"
                gap={1}
                sx={{
                  border: "0.2px solid grey",
                  cursor: "pointer",
                  backgroundColor: "white",
                }}
              >
                <Typography
                  style={{
                    color: colors[index],
                    fontSize: "19px",
                    fontWeight: "700",
                    marginTop: "10px",
                  }}
                >
                  {item.status}
                </Typography>
                <Typography
                  style={{
                    color: colors[index],
                    fontSize: "40px",
                    fontWeight: "700",
                  }}
                >
                  {item.number}
                </Typography>
              </Box>
            );
          })}
        </div>

        <Box
          component="section"
          sx={{
            p: 0,
            border: "1px solid grey",
            height: "auto",
            width: "100%",
            borderRadius: "10px",
          }}
        >
          <div className="btn_section">
            <button
              style={{
                width: "160px",
                height: "25px",
                color: "white",
                backgroundColor:
                  displayedText === "Trends" ? "#2828284D" : "#282828",
                outline: "none",
                border: "none",
                borderRadius: "5px 0px 5px 5px",
                cursor: "pointer",
              }}
              onClick={fetchGraphData}
            >
              Trends
            </button>
            <button
              style={{
                width: "160px",
                height: "25px",
                color: "white",
                backgroundColor:
                  displayedText === "Measurement" ? "#2828284D" : "#282828",
                outline: "none",
                border: "none",
                borderRadius: "0px 0px 5px 5px",
                cursor: "pointer",
              }}
              onClick={handleMeasurement}
            >
              Measurement
            </button>
            <button
              style={{
                width: "160px",
                height: "25px",
                color: "white",
                backgroundColor:
                  displayedText === "Performance" ? "#2828284D" : "#282828",
                outline: "none",
                border: "none",
                borderRadius: "0px 0px 5px 5px",
                cursor: "pointer",
              }}
              onClick={fetchrequestData}
            >
              Performance
            </button>
          </div>

          <div style={{ padding: "10px", marginLeft: "30px" }}>
            <h2>{displayedText}</h2>
          </div>
          {displayedText === "Measurement" ? (
            <Measurement />
          ) : (
            <div>
              <div
                style={{ display: "flex", gap: "10px", marginLeft: "30px", justifyContent: "space-between", alignItems: "center" }}
              >
                <div style={{ display: "flex", gap: "10px" }}>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      rowGap: "10px",
                    }}
                  >
                    <label>Start Date</label>
                    <DatePicker
                      selected={startDate}
                      onChange={(date: any) => setStartDate(date)}
                      dateFormat="yyyy-dd-MM"
                      placeholderText="Start date"
                      style={{
                        marginLeft: "10px",
                        padding: "5px",
                        height: "20px",
                      }}
                      className="cutom_datepicker_home"
                    />
                  </div>

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      rowGap: "10px",
                    }}
                  >
                    <label>End Date</label>
                    <DatePicker
                      selected={endDate}
                      onChange={(date: any) => setEndDate(date)}
                      dateFormat="yyyy-dd-MM"
                      placeholderText="End date"
                      style={{ marginLeft: "10px" }}
                      className="cutom_datepicker_home"
                    />
                  </div>
                </div>
                {
                  displayedText === "Trends" ?
                    <div style={{ padding: "1rem 1rem 0 0" }}>
                      <CSVLink data={downloadData}>
                        <button style={{ padding: "12px", width: "200px", cursor: "pointer", borderRadius: "5px", outline: "none" }}>Download Report</button>
                      </CSVLink>
                    </div> :
                    <div style={{ padding: "1rem 1rem 0 0" }}>
                      <CSVLink data={downloadDataPerfor}>
                        <button style={{ padding: "12px", width: "200px", cursor: "pointer", borderRadius: "5px", outline: "none" }}>Download Report</button>
                      </CSVLink>
                    </div>

                }

              </div>


              <div
                style={{
                  marginTop: "30px",
                  height: "55vh",
                  width: "90%",
                  marginLeft: "50px",
                }}
              >
                {Object.keys(graphData).length !== 0 && (
                  <TrendsChart data={graphData} />
                )}
              </div>
            </div>
          )}
        </Box>
      </div>

    </>
  );
}

export default Home;
