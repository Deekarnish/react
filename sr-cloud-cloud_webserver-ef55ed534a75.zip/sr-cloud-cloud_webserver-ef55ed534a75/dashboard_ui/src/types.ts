export enum NodeSetupStatus {
  Active = 1,
  InActive,
  Running,
  DUTChanging,
  Engaged,
  DUTChangeInit,
  VerificationOngoing,
  Verified,
  VerificationFailed,
  Maintenance,
  Error,
  OnHold,
  NotVerified
}

export const NodeSetupStatusLabel = new Map<number, string>([
  [NodeSetupStatus.Active, "Active"],
  [NodeSetupStatus.OnHold, "On Hold"],
  [NodeSetupStatus.Error, "Error"],
  [NodeSetupStatus.NotVerified, "Not Verified"],
  [NodeSetupStatus.Verified, "Verified"],
  [NodeSetupStatus.Maintenance, "Maintenance"],
  [NodeSetupStatus.InActive, "In Active"],
  [NodeSetupStatus.Running, "Running"],
  [NodeSetupStatus.DUTChanging, "DUT Changing"],
  [NodeSetupStatus.Engaged, "Engaged"],
  [NodeSetupStatus.DUTChangeInit, "DUT Change Init"],
  [NodeSetupStatus.VerificationOngoing, "Ver. Ongoing"],
  [NodeSetupStatus.VerificationFailed, "Ver. Failed"],
]);

export enum DUTStatus {
  InUse = 1,
  Obselete,
  Discarded,
}

export const DUTStatusLabel = new Map<number, string>([
  [DUTStatus.InUse, "In Use"],
  [DUTStatus.Obselete, "Obselete"],
  [DUTStatus.Discarded, "Discarded"],
]);

export enum RequestPoolStatus {
  Awaiting = 0,
  Completed
}

export const RequestPoolStatusLabel = new Map<number, string>([
  [RequestPoolStatus.Awaiting, "Awaiting"],
  [RequestPoolStatus.Completed, "Completed"]
]);

export type Menu = {
  id: number;
  name: string;
  link: string;
};

export interface AddNodeData {
  nodeIdentifier: string;
  templateId: number | null;
  serialNumber: string;
  macAddress: string;
  locationId: number | null;
  ipAddress: string;
  comment: string;
}

export interface AddUserDetails{
username:string;
email:string;
password:string;
roleId:number | null;
}

export interface DUTLibrary {
  dut_type: string;
  firmware: string;
  manufacturer: string;
  model: string;
  name: string;
  serial: string;
  update: string;
  user: string;
}

export interface TemplateLibrary {
  templateId: number;
  duts: Array<string>;
  name: string;
  updatedDate: string;
  createdBy: string;
}

export interface NodeData {
  name: string;
  serialNumber: string;
  nodeIdentifier: string | null;
  macAddress: string;
  ipAddress: string;
  templateId: number;
  locationId: number;
  comment: string;
  nodeId: number;
  lastUpdatedOn: Date;
  currentTemplate?: string;
  templateUpdateDate?: Date;
  dut1?: string;
  dut2?: string;
  dut3?: string;
  dut4?: string;
  statusId: number;
  firmwareVersion?: string;
  totalUptime?: string | null;
  templateName?: string;
  alertMessage?:String;
}

export interface NodeStatusList {
  nodeId: string;
  robotSerialNo: string;
  lastUpdated: string;
  messages: string;
  totalUptime: string;
  status: string;
  template: string;
  templateDate: string;
}

export interface RequestPool {
  trackingId: string;
  node: string;
  hapi: string;
  createdOn:string;
  lastUpdatedOn: string;
  messageDetail: string;
  createdBy: number;
  isCompleted: number;
}

export type Order = "asc" | "desc";

export enum Views {
  card,
  list
}
