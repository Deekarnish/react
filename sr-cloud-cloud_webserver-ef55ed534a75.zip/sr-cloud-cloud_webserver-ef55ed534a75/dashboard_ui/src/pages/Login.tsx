import {
  Avatar,
  Box,
  Button,
  Container,
  Grid,
  IconButton,
  InputAdornment,
  Paper,
  styled,
  TextField,
  Typography,
} from "@mui/material";
import React, { useContext, useState } from "react";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import robot from "../assets/images/robots.png";
import { ProgressContext } from "../context/ProgressContext";
import { createRequest } from "../services/ApiServices";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const LoginContainer = styled(Paper)`
  width: auto;
  height: auto;
  border-radius: 5px;
  padding: 40px 32px 90px 32px;
  border-color: #dfe0eb;
  background-color: #fff;
`;

const LogoImage = styled(Avatar)`
  background-color: #3751ff;
`;

const Heading = styled(Typography)(
  ({ theme }) => `
        color: ${theme.palette.grey[900]};
        text-align: left;
        margin-bottom: 30px;
      `
);

const LoginHeading = styled(Typography)(
  ({ theme }) => `
          color: ${theme.palette.text.primary};
          text-align: left;
        `
);

const LoginDesc = styled(Typography)(
  ({ theme }) => `
          color: ${theme.palette.grey[900]};
          text-align: left;
        `
);

const LoginError = styled(Typography)(
  ({ theme }) => `
          color: #F12B2C;
          text-align: center;
        `
);

const LoginButton = styled(Button)(
  ({ theme }) => `
            background-color: ${theme.palette.info.main};
            padding: 15px;
            &:hover {
                background-color: ${theme.palette.info.main};
            }
          `
);

function Login() {
  const { setProgressData } = useContext(ProgressContext);
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [userNameError, setUserNameError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [serverMsg, setServerMsg] = useState("");
  const [randomNumber, setRandomNumber] = useState(0);
  const navigate = useNavigate();


  useEffect(() => {
    const numbers = [1, 2, 5];
    const randomIndex = Math.floor(Math.random() * numbers.length);
    setRandomNumber(numbers[randomIndex]);
  }, []); 

  useEffect(() => {
    const isAuthenticated = sessionStorage.getItem("token");
    if (isAuthenticated && isAuthenticated !== "") {
      navigate(-1);
    }
  }, []);

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Validate userName and password
    let userNameValidationFailed = false;
    let passwordValidationFailed = false;
    if (userName === "") {
      setUserNameError("User Name is required");
      userNameValidationFailed = true;
    } else {
      setUserNameError("");
    }
    if (password === "") {
      setPasswordError("Password is required");
      passwordValidationFailed = true;
    } else {
      setPasswordError("");
    }
    // Submit form if there are no errors
    if (!userNameValidationFailed && !passwordValidationFailed) {
      setProgressData({
        isLoading: true,
      });
      createRequest({
        api: "getUserToken",
        method: "create",
        body: {
          userName: userName,
          password: password,
        },
      })
        ?.then(async (res) => {
          if (res.data.isSuccess) {
            if (res.data.token) {
              localStorage.setItem("roleId",res.data.roleId);         
              sessionStorage.setItem("user", res.data.userName);
              sessionStorage.setItem("token", res.data.token);
              sessionStorage.setItem("refreshToken", res.data.refreshToken);
              navigate("/", {replace: true, state: {token: res.data.token}});
            }
          } else {
            setServerMsg(res.data.message);
          }
          
          setProgressData({
            isLoading: false,
          });
        })
        ?.catch((err) => {
          setProgressData({
            isLoading: false,
          });
        });
    }
  };
  return (
    <Box
      display="flex"
      style={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#363740",
        alignItems: "center",
      }}
    >
      <Container maxWidth="xs">
        <LoginContainer elevation={3}>
          <Grid container direction="column" spacing={1} alignItems="center">
            <Grid item>
              <LogoImage src={robot} alt="logo" />
            </Grid>
            <Grid item>
              <Heading variant="h3">Robot Automation Framework</Heading>
            </Grid>
            <Grid item>
              <LoginHeading variant="h1">Log In to Dashboard</LoginHeading>
            </Grid>
            <Grid item>
              <LoginDesc variant="h6">
                Enter your username and password below
              </LoginDesc>
            </Grid>
            {serverMsg !== "" && (
              <Grid item>
                <LoginError variant="h6">{serverMsg}</LoginError>
              </Grid>
            )}
            <Box
              component="form"
              onSubmit={handleSubmit}
              noValidate
              sx={{ mt: 5 }}
            >
              <TextField
                sx={{ mb: 3 }}
                variant="outlined"
                fullWidth
                required
                error={!!userNameError}
                label="User Name"
                autoComplete="userName"
                autoFocus
                value={userName}
                onChange={(e) => {
                  setUserName(e.target.value);
                  setServerMsg("");
                  if (e.target.value !== "") {
                    setUserNameError("");
                  }
                }}
                helperText={userNameError}
              />

              <TextField
                variant="outlined"
                fullWidth
                required
                error={!!passwordError}
                label="Password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setServerMsg("");
                  if (e.target.value !== "") {
                    setPasswordError("");
                  }
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                helperText={passwordError}
              />
              <LoginButton
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3 }}
              >
                Log In
              </LoginButton>
            </Box>
          </Grid>
        </LoginContainer>
      </Container>
    </Box>
  );
}

export default Login;
