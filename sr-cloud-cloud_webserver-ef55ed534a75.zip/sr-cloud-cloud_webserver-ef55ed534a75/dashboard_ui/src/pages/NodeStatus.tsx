import React, { useEffect } from "react";
import NodeStatusView from "../feature/nodeStatus/NodeStatusList";
import { Navigate, useNavigate } from "react-router-dom";

function NodeStatus() {
  const navigate = useNavigate()
  const roleId = localStorage.getItem('roleId')

  useEffect(() => {
    const roleId = localStorage.getItem('roleId');
    if (roleId === "3") {
      navigate("/");
    }
  }, []);

  return (
    <>
      <div style={roleId === "2" ? { display: "none" } : {}}>
        <NodeStatusView />
      </div>
    </>
  );
}

export default NodeStatus;
