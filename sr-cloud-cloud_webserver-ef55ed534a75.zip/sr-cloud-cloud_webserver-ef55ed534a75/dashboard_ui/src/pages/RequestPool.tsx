import React, { useEffect } from "react";
import RequestPoolList from "../feature/requestPool/RequestPoolList";
import { useNavigate } from 'react-router-dom';

function RequestPool() {

  let roleId = localStorage.getItem('roleId')
  const navigate = useNavigate();

  useEffect(() => {
    if (roleId === "3") {
      navigate("/");
    }
  }, []);

  return (
    <>
      <div style={roleId === "2" ? { display: "none" } : {}}>
        <RequestPoolList />
      </div>
    </>
  );
}

export default RequestPool;
