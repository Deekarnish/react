import React, { createContext, useState, useMemo, ReactNode } from "react";

interface ProgressData {
  isLoading: boolean;
}

interface ProgressContextType {
  progressData: ProgressData;
  setProgressData: (data: ProgressData) => void;
}

const defaultProgressData: ProgressData = {
  isLoading: false,
};

const ProgressContext = createContext<ProgressContextType>({
  progressData: defaultProgressData,
  setProgressData: () => {},
});

interface ProgressProviderProps {
  children: ReactNode;
}

function ProgressProvider({ children }: ProgressProviderProps) {
  const [progressData, setProgressData] =
    useState<ProgressData>(defaultProgressData);

  const value = useMemo(() => {
    return {
      progressData,
      setProgressData,
    };
  }, [progressData]);

  return (
    <ProgressContext.Provider value={value}>
      {children}
    </ProgressContext.Provider>
  );
}

export { ProgressContext, ProgressProvider };
