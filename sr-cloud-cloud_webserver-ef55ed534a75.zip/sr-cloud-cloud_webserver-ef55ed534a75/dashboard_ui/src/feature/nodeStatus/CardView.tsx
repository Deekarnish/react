import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Grid,
  styled,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import StatusChipButton from "../../components/StatusChip";
import { NodeSetupStatus, NodeSetupStatusLabel, NodeData } from "../../types";
import Moment from "react-moment";
import axios from "axios";
interface CardViewProps {
  rows: NodeData[];
  page: number;
  rowsPerPage: number;
}

const NodeCard = styled(Card)`
border: 1px solid rgb(164, 165, 167);
background-color: #fff;
border-radius: 10px;
  width: 180px;
  height: 190px;
  background-color: #fff;
`;

const NodeCardHeader = styled(CardHeader)`
  background-color: #000000;
  padding: 10px;
  & span {
    color: rgba(252, 252, 255, 0.8);
    font-size: 18px;
    font-weight: 700;
  }
`;

const NodeCardContent = styled(CardContent)`
  padding: 0 2px;
  margin-bottom: 16px;
  & p {
    font-size: 12px;
    text-align: left;
    margin: 10px 0;
    font-weight: 700;
    color: #000000;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
`;

function CardView({ rows, page, rowsPerPage }: CardViewProps) {
  const [alertMsgData, setAlertMsgData] = useState<any[]>([]);

  const getAlertMsg = async () => {
    let body =
    {
      pageSize: 150,
      pageIndex: 1
    }
  
    try {
      let res = await axios.post("http://rafqa.us-east-1.elasticbeanstalk.com/node/alerts/all", body, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      setAlertMsgData(res?.data || []);
    } catch (error) {
      console.log("erorrr", error);
    }
  
  }
  
  
  useEffect(() => {
    getAlertMsg()
  }, [])
  return (
    <Grid
      container
      direction="row"
      rowSpacing={1}
      columnSpacing={3}
      sx={{ margin: "0 auto", padding:"0 30px 0 10px" }}
    >
      {rows
        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
        .map((row, index) => {
          console.log(row,"rrrrrrrrrr");
          const alertMsg = alertMsgData.find((alert: any) => alert?.nodeId === row?.nodeId);
          return (
            <Grid item key={row.nodeId}>
              <Box>
                <NodeCard variant="outlined">
                  <NodeCardHeader title={'Node ' + row.nodeIdentifier}></NodeCardHeader>
                  <NodeCardContent>
                    <p>Robot S/N: {row?.serialNumber}</p>
                    <p>Template: {row?.templateName}</p>
                    <p>Template Date: <Moment format="MMM DD, YYYY">{row?.lastUpdatedOn}</Moment></p>
                    <p>Message: {alertMsg ? alertMsg.alertMessage : "No Alerts"}</p>
                  </NodeCardContent>
                  <StatusChipButton
                    statusText={NodeSetupStatusLabel.get(row.statusId)}
                    status={NodeSetupStatus[row.statusId]}
                    height={30}
                    width={180}
                    fontSize={12}
                    topRadius={0}
                    borderRadius={9}
                  />
                </NodeCard>
              </Box>
            </Grid>
          );
        })}
    </Grid>
  );
}

export default CardView;
