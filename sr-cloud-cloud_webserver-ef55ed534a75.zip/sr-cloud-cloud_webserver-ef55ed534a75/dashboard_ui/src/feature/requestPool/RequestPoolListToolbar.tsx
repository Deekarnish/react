import styled from "@emotion/styled";
import { Typography, Toolbar, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import SearchBar from "../../components/SearchBar";
import ActionButton from "../../components/ActionButton";
import { useState } from "react";
const RequestListHeader = styled(Typography)`
  text-align: left;
  color: #252733;
`;

interface RequestPoolCountProps {
  requestCount: number;
  searchTerm:any;
  handleSearchChange:any
  handleFilterData:any
  header:any
  setHeader:any
}

function RequestPoolListToolbar({ requestCount,searchTerm, handleSearchChange,handleFilterData,header,setHeader}: RequestPoolCountProps) {
  const headerList = [
    {name:"TicketId",value:"TrackingId"},
    {name:"Payload Details",value:"hapi"},
    {name:"Node",value:"Node"},
    {name:"Created On",value:"CreatedOn"},
    {name:"Last Update On",value:"lastUpdatedOn"},
  ]

  const handleBankChange = (event:any) => {
    const selectedHeader = event.target.value as string;
    setHeader(selectedHeader);
  };
  
  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
      }}
    >
      <RequestListHeader sx={{ flex: "1 1 100%" }} variant="h6" id="tableTitle">
        All Requests{" "}
        <span
          style={{
            fontSize: "14px",
            fontWeight: 700,
            color: "#9FA2B4",
          }}
        >
          ({requestCount})
        </span>
      </RequestListHeader>

      <div style={{marginRight:"10px"}}>
      <FormControl sx={{ width: 180 }} size="small">
            <InputLabel
              id="demo-select-small-label"
              sx={{ fontSize: "0.75rem", marginTop: "0.25rem" }}
            >
              HeaderList
            </InputLabel>
            <Select
              labelId="demo-select-small-label"
              id="demo-select-small"
              value={header}
              label="Status"
              onChange={handleBankChange}
            >
              {headerList.map((list: any, i: any) => (
                <MenuItem value={list?.value} key={i}>
                  {list?.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          </div>
      
      <SearchBar searchTerm={searchTerm} handleSearchChange={handleSearchChange}/>
      <ActionButton text={"Sync"} width={76} height={24} handleFilterData={handleFilterData}/>
    </Toolbar>
  );
}

export default RequestPoolListToolbar;
