import {
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
  Box,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";
import React from "react";
import { TemplateLibrary, Order } from "../../types";

interface HeadCell {
  disablePadding: boolean;
  id: keyof TemplateLibrary;
  label: string;
  numeric: boolean;
  sort: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "duts",
    numeric: false,
    disablePadding: false,
    label: "Duts",
    sort: false,
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "Template Name",
    sort: true,
  },
  {
    id: "updatedDate",
    numeric: false,
    disablePadding: false,
    label: "Update Date",
    sort: true,
  },
  {
    id: "createdBy",
    numeric: false,
    disablePadding: false,
    label: "Created By",
    sort: true,
  },
];

interface TemplateLibraryListProps {
  numSelected: number;
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof TemplateLibrary
  ) => void;
  onSelectAllClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
  initiateChange: boolean;
}

function TemplateLibraryListHead(props: TemplateLibraryListProps) {
  const { order, orderBy, onRequestSort, initiateChange } = props;
  const createSortHandler =
    (property: keyof TemplateLibrary) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            {headCell.sort ? (
              <TableSortLabel
                active={orderBy === headCell.id}
                direction={orderBy === headCell.id ? order : "asc"}
                onClick={createSortHandler(headCell.id)}
              >
                {headCell.label}
                {orderBy === headCell.id ? (
                  <Box component="span" sx={visuallyHidden}>
                    {order === "desc"
                      ? "sorted descending"
                      : "sorted ascending"}
                  </Box>
                ) : null}
              </TableSortLabel>
            ) : (
              <React.Fragment>{headCell.label}</React.Fragment>
            )}
          </TableCell>
        ))}
        {initiateChange && <TableCell />}
      </TableRow>
    </TableHead>
  );
}

export default TemplateLibraryListHead;
