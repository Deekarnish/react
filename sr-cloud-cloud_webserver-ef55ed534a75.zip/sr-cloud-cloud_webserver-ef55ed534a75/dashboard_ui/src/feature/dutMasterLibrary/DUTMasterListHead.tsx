import {
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
  Box,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";
import { DUTLibrary, Order } from "../../types";

interface HeadCell {
  disablePadding: boolean;
  id: keyof DUTLibrary;
  label: string;
  numeric: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "dut_type",
    numeric: false,
    disablePadding: false,
    label: "Dut Type",
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "DUT Name",
  },
  {
    id: "model",
    numeric: false,
    disablePadding: false,
    label: "Model ID",
  },
  {
    id: "manufacturer",
    numeric: false,
    disablePadding: false,
    label: "Make",
  },
  {
    id: "serial",
    numeric: false,
    disablePadding: false,
    label: "Serial",
  },
  {
    id: "firmware",
    numeric: false,
    disablePadding: false,
    label: "Firmware Version",
  },
  {
    id: "update",
    numeric: false,
    disablePadding: false,
    label: "Update Date",
  },
  {
    id: "user",
    numeric: false,
    disablePadding: false,
    label: "Added By",
  },
];

interface DUTMasterListProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof DUTLibrary
  ) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
}

function DUTMasterListHead(props: DUTMasterListProps) {
  const {
    order,
    orderBy,
    onRequestSort,
  } = props;
  const createSortHandler =
    (property: keyof DUTLibrary) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

export default DUTMasterListHead;
