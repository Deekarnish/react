import styled from "@emotion/styled";
import { Typography, Toolbar, alpha } from "@mui/material";
import ActionButton from "../../components/ActionButton";
import SearchBar from "../../components/SearchBar";
import { useState } from "react";


const NodeListHeader = styled(Typography)`
        text-align: left;
        color: #252733;
      `
  ;

function DUTMasterListToolbar({ searchTerm, handleSearchChange,handleFilterData }: { searchTerm: string; handleSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;handleFilterData:any }) {
  console.log('ssssssssssssssssssssssss', searchTerm);
  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
      }}
    >
      <NodeListHeader
        sx={{ flex: "1 1 100%" }}
        variant="h6"
        id="tableTitle"
      >
        DUT Library
      </NodeListHeader>
      <SearchBar searchTerm={searchTerm} handleSearchChange={handleSearchChange}/>
      <ActionButton text={"Sync"} width={76} height={24} handleFilterData={handleFilterData}/>
    </Toolbar>
  );
}

export default DUTMasterListToolbar;