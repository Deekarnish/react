import React from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export default function TrendsChart({data}: any) {

  const options = {
    
    plugins: {
      title: {
        display: true,
      },
      tooltip: {
        callbacks: {
          title: function (tooltipItems:any) {
            const label = tooltipItems[0].dataset.label;
            if (label === "Average ResponseTime") {
              return [
                "Average Response Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "RequestSent") {
              return [
                "RequestSent Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "Response Received") {
              return [
                "Response Received Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "Active Count") {
              return [
                "Active Count Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "Error Count") {
              return [
                "Error Count Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "On Hold Count") {
              return [
                "On Hold Count Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            if (label === "Inactive Count") {
              return [
                "Inactive Count Time Information",
                "This line represents the average time taken",
                "for responses over the selected period."
              ];
            }
            return label;
          },
        },
      },
    },
    responsive: true,
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      },
    },
  };

  
  return <Line options={options} data={data} 
  
  />;
}
