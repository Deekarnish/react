import React from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Performance = ({ data }: { data: any }) => {
  // Extract labels and datasets dynamically from the response
  const labels = data.labels; // Dates for the x-axis
  const averageResponseTime = data.datasets[0]?.data; // Average response time data
  const requestSent = data.datasets[1]?.data; // Request sent data
  const responseReceived = data.datasets[2]?.data; // Response received data

  const chartData:any = {
    labels,
    datasets: [
      {
        type: 'line',
        label: 'Average ResponseTime',
        data: averageResponseTime,
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        yAxisID: 'y2',
      },
      {
        type: 'bar',
        label: 'Request Sent',
        data: requestSent,
        backgroundColor: 'rgb(75, 192, 192)',
        borderColor: 'rgb(75, 192, 192)',
        yAxisID: 'y1',
      },
      {
        type: 'bar',
        label: 'Response Received',
        data: responseReceived,
        backgroundColor: 'rgb(53, 162, 235)',
        borderColor: 'rgb(53, 162, 235)',
        yAxisID: 'y1',
      },
    ],
  };

  const options = {
    responsive: true,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    stacked: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Performance Chart',
      },
    },
    scales: {
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        title: {
          display: true,
          text: 'No of Requests/Responses',
        },
      },
      y2: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        title: {
          display: true,
          text: 'Time in Seconds',
        },
        grid: {
          drawOnChartArea: false, // only want the grid lines for one axis
        },
      },
    },
  };

  return (
      <Bar data={chartData} options={options} />
  );
};

export default Performance;
