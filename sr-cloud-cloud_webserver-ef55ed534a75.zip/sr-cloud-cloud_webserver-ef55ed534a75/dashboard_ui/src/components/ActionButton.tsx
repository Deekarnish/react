import { Button, Color } from "@mui/material";
import { styled } from "@mui/material/styles";
import React from "react";

interface ActionButtonProps {
  text: string;
  color?: string;
  width?: number;
  height?: number;
  radius?: number;
  fontSize?: number;
  fontWeight?: number;
  type?: 'submit' | undefined;
  action?: () => void;
  handleFilterData?: () => void;
}

function ActionButton({
  text,
  width = 238,
  height = 40,
  color = "#363740",
  radius = 100,
  fontSize = 11,
  fontWeight = 900,
  type = undefined,
  action ,
  handleFilterData
}: ActionButtonProps) {
  const TableAction = styled(Button)`
    font-size: ${fontSize}px;
    font-weight: ${fontWeight};
    height: ${height}px;
    width: ${width}px;
    margin: 0 20px;
    border-radius: ${radius}px;
    padding: 0;
    line-height: 1.3;
    background-color: ${color};
    &:hover {
      background-color: ${color};
    }
  `;


  const handleClick = () => {
    if (action) {
      action();
    }
    if (handleFilterData) {
      handleFilterData();
    }
  };
  return (
    <TableAction type={type} variant="contained" onClick={handleClick}>
      {text}
    </TableAction>
  );
}

export default ActionButton;
