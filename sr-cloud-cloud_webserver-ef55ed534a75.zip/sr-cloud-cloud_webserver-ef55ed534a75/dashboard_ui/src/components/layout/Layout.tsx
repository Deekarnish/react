import { Container, Grid } from "@mui/material";
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import SideNavigation from "./SideNavigation";

function Layout() {
  return (
    <Grid container direction="row" sx={{ backgroundColor: "#F7F8FC" }}>
      <Grid item xs={2}>
        <SideNavigation />
      </Grid>
      <Grid item xs={10}>
        <Container sx={{maxWidth: '100% !important'}}>
          <Grid container direction="column">
            <Grid item xs={12}>
              <Header />
            </Grid>
            <Grid item xs={12}>
              <Outlet />
            </Grid>
          </Grid>
        </Container>
      </Grid>
    </Grid>
  );
}

export default Layout;
