import { Dialog, DialogContent, DialogContentText } from "@mui/material";
import { styled } from "@mui/material/styles";
import React, { useContext, useEffect } from "react";
import { ApiContext } from "../context/ApiContext";

const ProcessStatusDialog = styled(Dialog)(
  ({ theme }) =>
    `
          background-color: ${theme.palette.primary};
          text-align: center;
          
          h2, p {
              color: #fff;
              white-space: pre-wrap;
              font-size: 14px;
              font-weight: 700;
        }
      `
);

const ProcessStatusDialogContentText = styled(DialogContentText)`
  width: 100%;
`;

function ProcessStatus() {
  const { apiData, setApiData } = useContext(ApiContext);
  const ProcessStatusDialogContent = styled(DialogContent)`
    background-color: ${apiData.backgroundColor};
    height: 109px;
    width: 175px;
    display: flex;
    align-items: center;
  `;

  useEffect(() => {
    if (apiData.showApiStatus) {
      setTimeout(() => {
        setApiData({
          showApiStatus: false,
          message: "",
          backgroundColor: "",
        });
      }, 2500);
    }
  }, [apiData.showApiStatus]);

  return (
    <ProcessStatusDialog
      open={apiData.showApiStatus}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <ProcessStatusDialogContent>
        <ProcessStatusDialogContentText id="alert-dialog-description">
          {apiData.message}
        </ProcessStatusDialogContentText>
      </ProcessStatusDialogContent>
    </ProcessStatusDialog>
  );
}

export default ProcessStatus;
