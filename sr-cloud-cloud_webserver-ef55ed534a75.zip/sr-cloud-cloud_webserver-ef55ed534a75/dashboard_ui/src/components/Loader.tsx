import { Backdrop, CircularProgress } from "@mui/material";
import React, { useContext } from "react";
import { ProgressContext } from "../context/ProgressContext";

function Loader() {
  const { progressData } = useContext(ProgressContext);
  return (
    <Backdrop
      sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
      open={progressData.isLoading}
    >
      <CircularProgress color="inherit" />
    </Backdrop>
  );
}

export default Loader;
