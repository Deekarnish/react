import React, { useContext, useEffect, useState } from "react";
import Box from "@mui/material/Box";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import DeleteIcon from "@mui/icons-material/Delete";
import edit from "../../assets/images/edit.png";
import UserModal from "./AddUserModal/UserModal";
import { ApiContext } from "../../context/ApiContext";

export default function BoxList({
  userinfo,
  setHandleChange,
  open,
  handleClose,
  saveModalData,
  onInputChange,
  addUser,
  updateUserDetails,
  editButton,
  setEditbutton,
  roleId,
  onDeleteUserDetails,
}: any) {
  const [upDateId, setUpDateId] = useState(null);

  const { setApiData } = useContext(ApiContext);

  const columns: GridColDef[] = [
    {
      field: "userName",
      headerName: "User",
      width: 250,
      editable: false,
    },
    {
      field: "email",
      headerName: "Email",
      description: "This column has a value getter and is not sortable.",
      sortable: false,
      width: 580,
    },
    // {
    //   field: "checkbox",
    //   headerName: "Active",
    //   sortable: false,
    //   width: 90,
    //   renderCell: (params) => {
    //     const handleCheckboxChange = (e: any) => {
    //       console.log(
    //         "Checkbox with ID:",
    //         "changed value to:",
    //         e.target.checked
    //       );
    //     };

    //     return (
    //       <input
    //         type="checkbox"
    //         onChange={handleCheckboxChange}
    //         style={{ cursor: "pointer", width: "50px", height: "18px" }}
    //       />
    //     );
    //   },
    // },
    {
      field: "deleteButton",
      headerName: "Delete",
      sortable: false,
      width: 80,
      renderCell: (params) => {
        const handleDeleteRow = (params: any) => {
          if (roleId === "1") {
            onDeleteUserDetails(params.id);
          } else {
            setApiData({
              showApiStatus: true,
              message: "Do not have the access",
              backgroundColor: "#A84849",
            });
          }
        };

        return (
          <DeleteIcon
            onClick={() => handleDeleteRow(params)}
            sx={{
              color: "red",
              border: "1.5px solid red",
              cursor: "pointer",
              marginTop: "10px",
            }}
          />
        );
      },
    },
    {
      field: "editButton",
      headerName: "Edit",
      sortable: false,
      width: 80,
      renderCell: (params) => {
        const handleEditRow = (params: any) => {
          setUpDateId(params.row);
          setEditbutton(false);
          if (roleId === "1") {
            setHandleChange(true);
          }
        };

        return (
          <img
            src={edit}
            alt="edit"
            onClick={() => handleEditRow(params)}
            style={{ cursor: "pointer" }}
          />
        );
      },
    },
  ];

  return (
    <div>
      <Box
        sx={{
          width: "100%",
          border: "none",
          outline: "none",
          "& .MuiDataGrid-root": {
            border: "none",
            outline: "none",
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#f5f5f5",
          },
          "& .MuiDataGrid-cell": {
            padding: "8px",
          },
          "@media (max-width: 600px)": {
            "& .MuiDataGrid-cell": {
              fontSize: "0.8rem",
            },
          },
        }}
      >
        <DataGrid
          autoHeight
          sx={{
            hover: "none",
            background: "#ffff",
            gap: "10px",
            border: "none",
            outline: "none",
          }}
          rows={userinfo}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 10,
              },
            },
          }}
          pageSizeOptions={[5, 10, 20]}
          disableRowSelectionOnClick
        />
      </Box>

      <UserModal
        upDateId={upDateId}
        open={open}
        handleClose={handleClose}
        saveModalData={saveModalData}
        onInputChange={onInputChange}
        addUser={addUser}
        updateUserDetails={updateUserDetails}
        editButton={editButton}
      />
    </div>
  );
}
