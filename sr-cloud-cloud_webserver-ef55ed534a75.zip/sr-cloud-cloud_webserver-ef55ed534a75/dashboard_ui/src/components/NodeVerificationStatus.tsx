import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import React from "react";

interface VerificationData {
  open: boolean;
  title: string;
  content: string;
  handleClose: () => void;
}

const NodeVerficationDialog = styled(Dialog)(
  ({ theme }) =>
    `
    background-color: ${theme.palette.primary};
    text-align: center;
    h2, p {
        color: #fff;
        white-space: pre-wrap;
        font-size: 14px;
        font-weight: 700;
  }
`
);

const DialogActionBtn = styled(Button)`
  background-color: #41c7fe;
  color: #fff;
  margin-bottom: 10px;
  width: 45px;
  font-weight: 700;
  padding: 0;
  font-size: 14px;
  min-width: auto;
  height: 30px;
  &:hover {
    background-color: #41c7fe;
    color: #fff;
  }
`;

function NodeVerficationStatus({
  open,
  title,
  content,
  handleClose,
}: VerificationData) {
  return (
    <NodeVerficationDialog
      open={open}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-description">
          {content}
        </DialogContentText>
      </DialogContent>
      <DialogActions sx={{ justifyContent: "center" }}>
        <DialogActionBtn onClick={handleClose}>Ok</DialogActionBtn>
      </DialogActions>
    </NodeVerficationDialog>
  );
}

export default NodeVerficationStatus;
