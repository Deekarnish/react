import React, { useEffect, useState } from "react";
import { Route, Routes } from "react-router-dom";
import ErrorBoundary from "./components/ErrorBoundary";
import "./App.css";
import Home from "./pages/Home";
import NodeSetup from "./pages/NodeSetup";
import Layout from "./components/layout/Layout";
import DUTMasterLibrary from "./pages/DUTMasterLibrary";
import NodeStatus from "./pages/NodeStatus";
import TemplateLibrary from "./pages/TemplateLibrary";
import ProcessStatus from "./components/ProcessStatus";
import RequestPool from "./pages/RequestPool";
import Loader from "./components/Loader";
import Login from "./pages/Login";
import ProtectedRoute from "./ProtectedRoute";
import TokenRefresh from "./components/layout/TokenRefresh";
import Settings from "./pages/Settings";

function App() {

  const logOut = () => {
    localStorage.removeItem("user");
  };

  return (
    <div className="App">
      <ProcessStatus />
      <Loader />
      <ErrorBoundary>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Layout />}>
            <Route
              index
              element={
                <ProtectedRoute
                  element={<Home />}
                />
              }
            />
            <Route
              path="nodestatus"
              element={
                <ProtectedRoute
                  element={<NodeStatus />}
                />
              }
            />
            <Route
              path="nodesetup"
              element={
                <ProtectedRoute
                  element={<NodeSetup />}
                />
              }
            />
            <Route
              path="requestpool"
              element={
                <ProtectedRoute
                  element={<RequestPool />}
                />
              }
            />
            <Route
              path="nodesetup/DUTMasterLibrary"
              element={
                <ProtectedRoute
                  element={<DUTMasterLibrary />}
                />
              }
            />
            <Route
              path="nodesetup/templateLibrary"
              element={
                <ProtectedRoute
                  element={<TemplateLibrary />}
                />
              }
            />
            <Route 
          path="settings"
          element={
            <ProtectedRoute
            element={<Settings />}
          />
          }
          />
          </Route>
          
        </Routes>
      </ErrorBoundary>
      <TokenRefresh logOut={logOut} />
    </div>
  );
}

export default App;
